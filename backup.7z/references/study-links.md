https://www.electronjs.org
https://www.w3schools.com/programming/index.php
https://developer.mozilla.org/pt-BR/docs/Learn_web_development
https://nodejs.org/pt/learn/getting-started/introduction-to-nodejs
Set-ExecutionPolicy RemoteSigned