document.getElementById('minimize').addEventListener('click', () => {
  window.electronAPI.minimize();
});

document.getElementById('maximize').addEventListener('click', () => {
  window.electronAPI.maximizeRestore();
});

document.getElementById('close').addEventListener('click', () => {
  window.electronAPI.close();
});

window.electronAPI.onWindowStateUpdated((data) => {
  const status = document.getElementById('status');
  status.textContent = `Janela: ${data.width}x${data.height} em (${data.x}, ${data.y})`;
});

document.getElementById('openImageBtn').addEventListener('click', async () => {
  const imageData = await window.electronAPI.openImage();
  if (!imageData) return;

  const info = `
    <strong>Nome:</strong> ${imageData.name}<br>
    <strong>Caminho:</strong> ${imageData.path}<br>
    <strong>Tamanho:</strong> ${Math.round(imageData.size / 1024)} KB<br>
    <strong>Dimensões:</strong> ${imageData.width} x ${imageData.height}
  `;

  document.getElementById('imageInfo').innerHTML = info;
  document.getElementById('imageDisplay').innerHTML = `<img src="${imageData.dataUrl}" alt="Imagem">`;
});