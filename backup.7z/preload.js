const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  controlWindow: (action) => ipcRenderer.send('window-control', action),
  openImageDialog: () => ipcRenderer.invoke('open-image-dialog'),
  openPreview: () => ipcRenderer.send('open-preview'),
  onImageData: (callback) => ipcRenderer.on('image-data', callback),
  onPreviewImage: (callback) => ipcRenderer.on('preview-image', (_e, dataUrl) => callback(dataUrl))
});

