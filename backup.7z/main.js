const { app, BrowserWindow, ipcMain, dialog, nativeImage } = require('electron');
const path = require('path');
const fs = require('fs');

let mainWindow;
let previewWindow;
let lastImageData = null;

const lastImagePathFile = path.join(app.getPath('userData'), 'last-image.json');

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 800,
    height: 600,
    frame: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js')
    }
  });

  mainWindow.loadFile('index.html');

  // Restaurar última imagem
  if (fs.existsSync(lastImagePathFile)) {
    try {
      const { path: filePath } = JSON.parse(fs.readFileSync(lastImagePathFile));
      const stats = fs.statSync(filePath);
      const image = nativeImage.createFromPath(filePath);
      const size = image.getSize();
      const ext = path.extname(filePath).slice(1);
      const base64 = fs.readFileSync(filePath).toString('base64');

      lastImageData = {
        name: path.basename(filePath),
        path: filePath,
        size: stats.size,
        width: size.width,
        height: size.height,
        dataUrl: `data:image/${ext};base64,${base64}`
      };

      mainWindow.webContents.once('did-finish-load', () => {
        mainWindow.webContents.send('image-data', lastImageData);
      });
    } catch (err) {
      console.error("Erro ao restaurar imagem:", err);
    }
  }
}

app.whenReady().then(() => {
  createWindow();

  ipcMain.handle('open-image-dialog', async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
      properties: ['openFile'],
      filters: [{ name: 'Images', extensions: ['jpg', 'png', 'jpeg'] }]
    });

    if (!result.canceled && result.filePaths.length > 0) {
      const filePath = result.filePaths[0];
      const stats = fs.statSync(filePath);
      const image = nativeImage.createFromPath(filePath);
      const size = image.getSize();
      const ext = path.extname(filePath).slice(1);
      const base64 = fs.readFileSync(filePath).toString('base64');

      lastImageData = {
        name: path.basename(filePath),
        path: filePath,
        size: stats.size,
        width: size.width,
        height: size.height,
        dataUrl: `data:image/${ext};base64,${base64}`
      };

      fs.writeFileSync(lastImagePathFile, JSON.stringify({ path: filePath }));

      return lastImageData;
    }

    return null;
  });

  ipcMain.on('open-preview', () => {
    if (!lastImageData) return;

    if (previewWindow) {
      previewWindow.focus();
      return;
    }

    previewWindow = new BrowserWindow({
      width: 300,
      height: 300,
      alwaysOnTop: true,
      frame: false,
      resizable: false,
      webPreferences: {
        preload: path.join(__dirname, 'preload.js')
      }
    });

    previewWindow.loadFile('preview.html');

    previewWindow.once('ready-to-show', () => {
      previewWindow.webContents.send('preview-image', lastImageData.dataUrl);
    });

    previewWindow.on('closed', () => {
      previewWindow = null;
    });
  });

  ipcMain.on('window-control', (_e, action) => {
    if (action === 'minimize') mainWindow.minimize();
    else if (action === 'maximize') mainWindow.isMaximized() ? mainWindow.unmaximize() : mainWindow.maximize();
    else if (action === 'close') mainWindow.close();
  });

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});