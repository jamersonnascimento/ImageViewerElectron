# ImageViewerElectron
Um pequeno projeto de uma visualizador de imagem usando Electron. Este projeto serve para meu aprendizado com esta tecnologia
